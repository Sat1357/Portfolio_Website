import React from 'react';
import {v4 as uuid} from "uuid";
import RecommendationCard from './RecommendationCard';

 function RecommendationSection() {
     const recommendations = [
         {
             id: 1,
             name: "Random guy 1",
             company: "ABC company",
             designation: "CEO",
             message: "He is the good engineer",
        },
        {
            id: 2,
            name: "Random guy 2",
            company: "ABC company",
            designation: "Director",
            message: "He is a lazy person",
       },
       {
        id: 3,
        name: "Random guy 3",
        company: "ABC company",
        designation: "Manager",
        message: "He is an excellent developer",
   },
   {
    id: 4,
    name: "Random guy 4",
    company: "ABC company",
    designation: "HR",
    message: "He gets the things done so quickly",
},
     ];
    return (
        <div className="container-fluid my-5">
        <div className="row text-center py-5 d-flex flex-nowrap scrollbar overflow-auto">
            {
                recommendations.map((recommendation) => (
                    <RecommendationCard key = {uuid()} 
                    id={recommendations.id}
                    name={recommendation.name}
                    company={recommendation.company}
                    designation={recommendation.designation}
                    message={recommendation.message}
                     />
                ))
            }
           </div>
           </div>
    );
}
export default RecommendationSection;