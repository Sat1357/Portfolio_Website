import React from 'react';
import ProjectCard from './ProjectCard';
function ProjectSection() {

const projects = [
    {   id : 1,
        title : "Project 1",
        imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeEPjxJHi3V2zcRWSZEfzQdqj9turuPu65ZA&usqp=CAU",
        excerpt : "This is my project about....",
    },

    {   id :2,
        title : "Project 2",
        imageUrl:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhAQEhIVEBUQFg8QFhMXFhUVEhUVFRUXFhUVFRYZHSogGBolGxcWIjEhJSkrLi4vFx8zODMtNygtLisBCgoKDg0OGhAQGy0mICUtLS0tLS8vLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJ8BPgMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAwEEBQYHAgj/xABOEAABAwIDAwYICgMQAwEAAAABAAIDBBEFEiEGMUETIlFhcZEHFCMyUlOBsRdUkpOhosHR0uFCcvAVFjNDRGJzdIKElLKzwsPTNDWDJf/EABoBAQADAQEBAAAAAAAAAAAAAAABAwQCBQb/xAAzEQACAQIDBQUHBQEBAAAAAAAAAQIDEQQSIRMUMUFRBWFxkaEyUoGxwdHwFSIzkuHxQv/aAAwDAQACEQMRAD8A6ciIvmD1giIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAitMTxKGnZykzxG3dc7yehoGpPYtYqfCPSN0YyaTrDWtb9Z1/oVtOhUqawi2cSqwjxZuSLn7/AAmtuA2mOpAu6QAdps0rMu2kfwnwsf35x/4VduNf3fVfcr3ml1NnRauNpH+vwv8Axr/+pYmo8I3JyOjdAyTIbZ4p88buthMYuFO4V/d9V9xvNLqb8i0mm8JNMSA+KZnWAxwH1gfoWzYRjdPUgugkD8tszdQ9t912nW3XuVNTD1aesotHcasJcGZBERUlgRFVAUREQBERAEREAREQBERAEREAREQBERAEREAREQBEWHxOqn8Zgp4nsZysc8hc5hk/gywAABzfSK6jHM/zkRKWUzCLS8MxbEJ+WLZqGMRSvhtKXRudltzgLnTX3q+zYl8awv5x61/p9Xu8yneYd5syLWc2JfGsM+cembEvjWGfOPT9Pq93mN5h3mzItZzYl8awz5x6YRi9R4zLT1D4JMjGPzQXLecfSO/sXNTB1IRcnayJjXjJpI1fwrvJqKdupAiLgNTYl5BP1R3LSLHoPcVvnhFp5Jq6jhhDS+aLKMxs3R0jiSRwsCVZfvAr/SpvlyfgXq4bEU6VCCm0tPqzFVhKVSVlzNQseg9xSx6D3FbBFstWmWaG0IMGTM4vdkOcXblsLnTpAUsux1cGl3kHWBNg99zbgLttdb1K6uuBllOMXaTsa1Y9B7iqWPQe4/csxQYJVSxxyt5ENka17QXPvlIuCbA8FHiWG1FOGSSCMtL2M5pcSCd1wQOhVLEU3LLdXNTwtZRzOLt1MxF4OsQLWuMcbMwDsrpWBwv0jgVmtk9iK+nqo5SIw0CRrssrSSCw2FuPOyn2LXvCtWuGKVTbBwYKcC9zYGFjrDXQXJ71B4NqkuxKj0As5+7rieEqLNTafBplUHaSt1OyxvvcHQi4I6CvatKt9ppLem73q4ikuvlpK0mujZ7C1SZM2SNjXyzODI4hmc47gOk9QTarFTDAGwgPnqSIKdm8GR4NnH+Y0XcTusF7ppA0kOGZrgWuFrgjs4rH4RhMMExmM/KMiaYqaI/ydjzmka3idbAE6hrQ1etgZ0lT4pPncw4iMnMtaPCBRNZCHF9wHvefOe8+e4+0d1hwWUY4EXCs8Rq+UkLtwGg6bDp715gksvMrTUqkmuFzZTi1BJl8io111VVnQREQBERAEREAREQBERAEREAREQBERAFY4hgUNS5jpQ4uZdrS172EBxF/NIvuCvlJDv6NQtWC/nXx+RTiPYZgX+DqhLi3kiTvJ5WT7T1qvwa0XqT86/71sz2NzEZ9NOd53QnIs9Z9Ur3szPNsaz8GtF6k/Ov+9Pg1ovUn51/3rZuRZ6z6pTkWes+qUzMWNZ+Dai9SfnZPvXiDZympbvgYWF/NN3OdoNeJW08iz1n1SsXifmt7fsWbFu9CXh9UXUP5Imj4mf8A9jDOpkn+WZdAXMNr4c+I0Dczmcy+ZhLXjKZHaOG7csxyT/jFR8/J968ypTUqdJ3/APP1Z6VChOo5uPX6IycX/mV390/0yryTcewrkmOVEtPVzmKeYF4jc5xkcXG7dxPG3C+5WU2OVTmlpqZiHAgjO7UHeF72HajSiu5HgYrDSdafib5s1/4dH/QU/wDkarDbt1qYHoliPdmUWBUVqeDykvOYx1hI4AZhewAOg1XutwVk0lLG+SUtfOxhBkc7Qg3tfcdLX6ysEcK6dTaN6LX6nvVO0IToumou7VuXgS7Z4LS19U+thxWhjbO2IlksoZI0tY1li3eNGjQ2I1UmwmysUFbBN+6VDNyZe7JFMHyO8m8aD237AVnfg2w71T/npfxLWYsGipMahhhuGGMygOOYguimBFzqRzb69K7WNp1IyUb6Rbs0uXgzznh5Rav1R0iVjpJHuY0uBc43APSpG00jd7HD2E+5eaLEHxizbEE3sQp341Kd2Vvsv715C2ElmlJ3fcje1UWiSt4krInn9B3cVa4tDycUs7mkNhY+Rxt+ixpcfbYKUY1N/NPs/NWuMV8k9PUU5yt5eKWLNY6Z2Ft9/WuoxwrespeRy3W5JeZpHwgQepl+p+Jeh4QoPUy/U/EsJ+8Op9OL5T/wp+8Op9OL5T/wrdsuz/e9WZ8+J6eh0DZvHo6pjpIw5uVxYWute9gbixsdCs6CtP2Qwd9LG5j3Nc57y/m3sBlDQLnsW0wS3XmVsiqSVP2eRrhmyJy4k6IirOgiIgCIiAIiIAiIgCIiAIiIAiIgCq3eO0KikgOvtCtoUlUqKLK6s8sbkjizOTlOXgBovWaP0Hd6mke7OTkubDTzrblXlH+rHyCvV3Na6r+qMe2/LsgzR+g7vTNH6Du9T8o/1Y+QU5R/qx8gqdzXd/VE7fu9WQF0foO71jK/zR2/YsyZH+rHyCsRifmt7fsWfE4RRg5X4dyXyLKNduajbj3nONsqhseIUL3mzQwgmxPnGRo3dZCynjrOl3yH/hVZxfHMKvrzZT3MnI+ldZurqWHjUo02+n1ZbDGToSlGKXHn4I+ZdpqhstVKY7usGNNmuvdosdLX3rGvjcASWuAHEtcB7l2HHGAYjXEC1xSXI4+TO9QSahwOtwR9C7li9k9mo8Lcyyngd4jtnKzd3a3+mrYLi8AggaZA0tYxhBvcFoAPuU78fp2zUjjICGzxvcQCcrQCC46dYWsUH8FH+qz3LJYO0GqpLi/lmH6CtzipXj8Dxto1qd0oI43NbIXNIcA4C9tDqCVMaSme/NkhfIBa9mGQDXjvAsT3rWbLSqnm47TuGjhCDcb78nOPcqVhqdCm2uSb8SKeKlXqKLVr951Gvwi3OiHa37Rf3Kwdh8noO7lsOITFkUsg1LGPeBwJa0kD6Fwj4RcUJzeM2vrlEUGUdQuwm3tWaXZ1Oo8y08DasVKKs9Tqho3+g75JXk07vRd3Fc0Z4S8SH8cx3bFH9gCmZ4UsRG8wntjP2OC4fZK5Sfodb73HQXR9X0LzlWit8LVcN7aY/wBh4/5FKPC5VcYKZ3UBIP8AcVy+yZe96f6dLGrobplXtmiymLkGOGTLlL7Ejou29ljQF5lek6U3Bu5qpzzxuXcUl+1e1aM0Vyx11wSekREAREQBERAEREAREQBERAEREAUkG/2hRqSHf0ahasF/PH4/IoxH8bLxzX5yA7Wwud3QvXJy+l9ZQSmMPIMgAAGpIJ4J5L1o7vzXt549V5mDK+hPycvpfWTk5fS+soPJetHd+aeS9aO781GePVeaGWXQnMcvpfWWHxPzW9v2LIHkvWju/NY3EHAhtjfXhqs+LnF0ZJNeaLaEXtI6HN9tcWdSYhQ1TGh7oWFwa7QOuZGEEjdo46q7+GyX4jH/AIh3/UsZ4TcPmkmhMcMsoEdiWRveAczjYloNlpf7jVXxWo+Yl/CrcJOmqEMzXDqRXU9pKyfkdC2fxKsxKorKpkcEbTyDS1z3jKWtIaAQwl2lySQOCzVVhFeGPLW0xcGuIHKyb7f0Y947Qsb4GWER1rSC0tliBBFiCGuBBB3G66HL5ruw+5ebi6lq8lZcvobcPWqRpJKT9Pscs2d2BrJ6Wnma+na2WOORgc6TNkcAWl1mEAkW4qmL7J11E6ln8hJ5eNoDXP0cQbZrtFmkB2ouRpouo7Bf+tw3+q0n+k1WXhC/gab+tQf5XrZvU8/LmYYUYykovnb1JsLw8TRteJQDYZm5ScruIvmFx0G2qtY9gwa5le+oLsjcgiEeUWyvGri4388ncOCxFLVPjdmY4sPVx6iOKiZtvWfuhFR3j5N7C8nJ5S+SR2+9t7W8F1Txm0i1Lo2+9LiacR2YsM88OF7LjdXOkVlUyNt3cdLcT7Fqb8MwsknxCIk6+YwDu3KssrnnM4lx60DVgn2jUb/ZoiyGFjb93EqKDDhuw6nPbFEfe0qVopG+bQU4/wDnGPcxQhqZFU8dX970Ot2pLkXbayIebSwt/st+xq9jGCN0UY9issiZFy8XX975fYnYU+hLWVr5bZrAC9gBbf2qOJ1lTKqgKiUnJ3k7ssilFWSLkBegoYnWVyGqAVBVUARSQEREAREQBERAEREAREQBERAF5kLrc02K9IpjJxd07EOKaszGyOJJLt6vqGZgAzHTXS9ivFRAHa8ferIssuEmp5+PidyalHKZ01UH7O/NRw1ENudqeo/msPlVzQ0QeQC4tJLgNL7hc8VqpupVnaMY38EUzjCCu2zJeMwfs781XxmDr+V+ax3i8OR0vLHK1wjJEbicxIAAG83zN4cQp5MMY3PeQ+TDXO5l9HXtYA3Pmlat3xHuw8kVZ6PVirxCnbYZ2sO/nPA06rlYxuIQFpaZWA20u5mW4N73ve5Vtjvg7grzFM6okaMgy5GtsWm7gecCeK1yp8EVM2RsQnmcXNzAnkx6Wnm9Stj2fn1nJJtapLT5oqlilT4K65O+pzvEMQljqat0M0kOeaa5ikezMOUcRcsIuPvUEmN1bgWuq6lwcCC11RMWkHeCC6xCuNq8IZS1LoGOc5rWsN3Wvzhc7gAsSvVVKKSTSdlbgY8+bVczNUWKVLGMZHVVMbQNGMqJmMF9dGtcAPYshg4krKuip6moqJWPmaLPnleRoSSwuccp0tca6rARTNsBfcAsrszikUNZSTyOsyKVrnEAmzbEE242vwXbS6A7mNgqLoqP8ZWf9q57iOER0uPRRRF+V0Il573yOBdHO0jO8lxHMG8neug/CLhfxxnyZPwrn2IYzBV47DNTv5SNsIizWIBc2OdxtcA254+lY6kVGlOyt+1/IvjJynG75rmzdGpUPyse8NL8jXOyt851hew61eYXC05yRnytJDL+cddOlYfwhUYfRh4jlDy67Y4/Ozm7Wlw35NdwC8OlhnNKTf8Ay9vD1PQqVcrat+fP0NVk2+5+dkRdEItWlvObMb2u+9sm7h0rZ9ncbZUxt5zOVyB742m+W5t+w4X7CdV2c2gpqemMEwLHxmQPZkJLyXHfwv8Ao69C9+DqKQcpI0Rcm4uBtrM1wy5W34Mtc2K2YjDwVObUHHK0k7+1+LUop1JOUVmvfiuhv2VMqrC6/apbLyjYQ5VXKpcqWQi5EApY3JZVAUi5Kio1VUkBERAEREAREQBERAEREAREQBERAFHNFftUiqhJYFq9Nme3zHW48OxXMkd1NhkF36i4aCde5WUVJ1EoOzZxUaytsxrjJK0sIMjSbluUFpN73OnSrmolqGWLyRm/VO7gVlKzFGxuyNbnI3gaAaX9yUtYycFjm2Nr5d/tBXoZdciqvN6GZvTNkVjl+3m2VdSyRMgmyNczMQWMdrmcOI00AWoTeEPEXHM6ZpNrX5Nm7XTd1lbD4YMMLKinJvldG4NdpqWvOYdozN71oPirev6F6mFUlSjm42182Y6+WUnbgUxXEpKiQzSkOeQ1pIAaLNFhoFaK88Vb1/Qnirev6FoK+BaIrvxVvX9CeKt6/oQkuYNm617WvZSzva8BzXCNxaQdQQbahbDsPs/Vx1kL5KaaNo5S7nRuAF4ngXNukjvW6YJtvRxUsEDqmSNzIIYbNhe7K9vnOB3Ho79+ls3Q7c0c0rY46iUue55DeSc3TkzzbnQWsXdqoq6wknorPX4HcNJJonga9puA5p6QCEm5Rxu7M49Nj03+1XkdcAADNM4hsjS7KwElx0dpoCPsHXe4hxVgdI4ukcHZbNsLNAHDXivI3ahbLtdOl0b9rUvfJ8zn9dhFA12Vz2RPZKJ3Xe3lMx1yuL7nKdDZZ6jijAzRBobITJdoFnF36Wm/tWsbWYLPPVzzRszMkLS0lzQdGNG4npBV5idPM2gZAzmyOFPA6xvbO5rHajhrYnoJVdenB5Uql7u3Hh3ilUldtwtZGMxzaF9RJ4lRG+YgOmBI3HXKRuaNOdx4b9dsfiZpqR0lQ7lnQtF3NblMhuGt01sdRc9p6l62Qw+Cia5tgRIBykrvONuJ6Gb9OCt9r9n5pXxNY4CicA97mm73G92sP806EHdvvwv240qiWz9iPtdfHrquFiLzi3m9p8On20MjhGKNmAacrZQxkj42uzhrX3y86wB3fsFkcq1/CsKhpwRAzk8xBJuSTbdcuJKzsE2btXnzcXJ5OBoSaWp7yquVVRQSAEREAREQBERAEREAREQBERAEREAREQBERAVV9hVud06dysF6Y4g3GhCtoVVSqKbVzipHNGxHN5KoL3A2u5w67g6BesIBfMZA3K0Zt27UWt9qyJro8vlLDqIvfsCtpMaYNGMJ7mj9vYt2WlGSk6iy3zW53KM02rKOtrXNU8JGB+OPZlfkfAC0X8w5rEg23bhquey7F1g3MY/9V4/3WXU5ZC5znHe4kplVS7RrRbta19Lne6Qa14nI3bLVo/iHexzD7nKI7OVfxeTuXYMiZVZ+rVecV6/c53OHVnHxs7V/F5O5SM2YrD/J3e0sHvK65lVMqfq1X3V6/cjcodWcsi2NrDvjaz9Z7f8AaStn2V2TNO/lpXNc8AhrW3ytvoTc7zbTdxK23KgYqavaFapFxdkn0LYYanB3KAKuRVDVIAsJeRZEyqbKlkJuc32hNcWRcvLkbVyCPxZoaHtaToN13cL677X36dO2ckZDGyl/i2tDG31sOg9RWPmw+Nz2zFjTI0ZWvIBcBroDw3nvXsBbd8klHKrW4rRJ38O7S5n2Cd78y8xKmax+VpvfW3FvUoG6aheHN4r2wrJOSlJtK3cXRTSSZdxSX7VKrRoVwx11APSIikgIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA8vYCLFWMsOUrIKjmgixUEmODV7aF7fHY2VLKCRlTKvYUlkBb2SynyplQEFkyqfKmVCLkIaqgKXKlkJKAKuVegF6AUkEeVeHxXVxlTKlhcswFUsVw6JRgISIypAF5LeKkYoOT0Cqoi6AREQBERAf/2Q==",
        excerpt : "This is my project about....",
    },

    { id:3,
        title : "Project 3",
        imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdLHEnF60OhMca_eNk6kacA2kpDqsnIcQ9DA&usqp=CAU",
        excerpt : "This is my project about....",
    },
];
    return (

        <div className="container text-center my-5">
        <h1 className="font-weight-light">
            My <span className="text-info">Projects</span>
        </h1>
        <div className="lead">I build products just like this websites</div>
        <div className="row my-5 pt-3">
            {
                projects.map((project) =>  (
            
                    <div key = {project.id} className=  "col-12 col-md-4 my-2">
                    <ProjectCard project = {project}
                     />
                     </div>
                ))}
        
          
          </div>
        <div className="my-5">
            <a href="/" className="text-dark text-right">
                <h5>
                    See my projects
                    <i className="fas fa-arrow-right align-middle"></i>
                </h5>
            </a>
        </div>
    </div>
    );
}


export default ProjectSection;