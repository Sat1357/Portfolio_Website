import React from 'react';

function About() {
    return (
          <div className="container text-center my-5">
        <h1 className="font-weight-light">
             <span className="text-info">About</span> me
        </h1>
        <div className="lead">I can develop the front and back of an website</div>
        <div className="row">

            <div className="col-12 col-md-6 text-dark py-3 px-5 text-justify">
                <h4>What can I do?</h4>
                <p>
                    hdiudi ojdd jkndjidnsidjn n fisd adia  idhahd bdabnb jdbkbds jbjdsndjns jnjdnndn ndnandj ja jad ndhhadi jdbadad nbaidbabidaidbia


                </p>
            </div>

            <div className="col-12 col-md-6 text-dark py-3 px-5 text-justify">
                <h4>What am I doing currently?</h4>
                <p>
                    hdiudi ojdd jkndjidnsidjn n fisd adia  idhahd bdabnb jdbkbds jbjdsndjns jnjdnndn ndnandj ja jad ndhhadi jdbadad nbaidbabidaidbia
                    

                </p>
            </div>
        </div>

            <div className="row">
                <div className="col-12 col-md-6 text-dark py-3 px-5 text-justify">
                    <h4>What do I believe in?</h4>
                    <p>
                        hdiudi ojdd jkndjidnsidjn n fisd adia  idhahd bdabnb jdbkbds jbjdsndjns jnjdnndn ndnandj ja jad ndhhadi jdbadad nbaidbabidaidbia
    
    
                    </p>
                </div>
    
                <div className="col-12 col-md-6 text-dark py-3 px-5 text-justify">
                    <h4>How I can help you? </h4>
                    <p>
                        hdiudi ojdd jkndjidnsidjn n fisd adia  idhahd bdabnb jdbkbds jbjdsndjns jnjdnndn ndnandj ja jad ndhhadi jdbadad nbaidbabidaidbia
                        
    
                    </p>
                </div>
           </div>
         </div>

    );

}

export default About;