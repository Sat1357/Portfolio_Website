import React from 'react';

function Footer(){
    return( <footer>
        <div className="container-fluid text-center" style={{backgroundColor: "black"}}>
            <div className="row py-5">
                <div className="col-12">
                    <h2 className="text-light mb-4">Interested in working with me?</h2>
                    <button className="btn btn-outline-light btn-lg">Let's Talk</button>

                </div>
            </div>
            <div className="row">
                <div className="col-12 col-md-4 py-3">
                    <h5 className="text-info pb-3">More Links</h5>
                    <a href="/" className="text-light d-block">Blogs</a>
                    <a href="/" className="text-light d-block">Home</a>
                    <a href="/" className="text-light d-block">Projects</a>
                    <a href="/" className="text-light d-block">Contact Me</a>
                    <a href="/" className="text-light">Write a recommendation <i className="fas fa-heart text-light"></i></a>

                </div>
                <div className="col-12 col-md-4 text-light text-justify py-3">
                    <p>This is my page and here you can refer this as Cv or Resume and fidsbd dsfkb bfbbbbibbdi bhfbsbfbs ubfbibfbius hfiuhds bgf d jf jijdbsjifbbsbfs bbfb jfsbfbisbfibsf</p>

                </div>
                
                    <div className="col-12 col-md-4 py-3">
                        <h5 className="text-info pb-3">Social</h5>
                        <a href="/"><i className="fab fa-linkedin-in text-light h1 d-block"></i></a>
                        <a href="/"><i className="fab fa-github text-light h1 d-block"></i></a>
                        <a href="/"><i className="fa fa-envelope text-light h1 d-block"></i></a>
                    </div>
                    </div>
                
                <div className="row">
                    <div className="col-12 text-muted">
                        <p>Copyright©Sathwik H S 2000</p>
                    </div>
                </div>
            </div>


        
    </footer>);
}


export default Footer;