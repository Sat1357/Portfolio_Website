import React from 'react';
 function ProjectCard(props) {
     const {project} = props;
    return (
        <div className="card h-100 shadow">
                        <img src={project.imageUrl}  alt={project.title} className="card-img-top"/>
                        <div className="card-body">
                            <h4 className="card-title">{project.title} </h4>
                            <p className="card-text">{project.excerpt}</p>
                            <a href="/" className="stretched-link"></a>
                        </div>
                    </div>
    );
}


export default ProjectCard;