import React from 'react';
import {v4 as uuid} from 'uuid';

 function Skill(props) {
     const {name,imageUrl,starsTotal,starActive} = props;
     const starsList = [];
     for(let i=0;i< starsTotal;i++){
         if(i<starActive) {
            starsList.push(<span key = {uuid()} className="text-info">★</span>);

         }else{
            starsList.push(<span key = {uuid()} className="">☆</span>);

         }
         
     }
    return (
        <div>
        <img src={imageUrl}
         alt={name}
          className="rounded-circle"
           style={{width: "100px", height: "100px"}} 
           />

        <div style={{fontSize: "30px"}}>
            {starsList}
           
        </div>
    </div>
    );
}
export default Skill;